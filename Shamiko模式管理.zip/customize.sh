echo "Shamiko模式管理"
echo "快速切换Shamiko的工作模式"

shamiko="/data/adb/shamiko"
if [ -d "$shamiko" ]; then
    echo "已检测到Shamiko"
    echo "安装完成"
else
    echo "请先安装Shamiko"
    echo "将不会进行任何更改"
    exit 1
fi
