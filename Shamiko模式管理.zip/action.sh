shamiko="/data/adb/shamiko"
whitelist="/data/adb/shamiko/whitelist"

if [ -d "$shamiko" ]; then
    echo "Shamiko状态正常"
    if [ -f "$whitelist" ]; then
        echo "当前是白名单模式"
        rm "$whitelist"
        echo "已切换为黑名单模式"
        exit 0
    else
        echo "当前是黑名单模式"
        touch "$whitelist"
        echo "已切换为白名单模式"
        exit 0
    fi
else
    echo "Shamiko状态异常"
    echo "将不会进行任何更改"
    exit 1
fi
